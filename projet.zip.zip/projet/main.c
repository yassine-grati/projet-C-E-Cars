#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <windows.h>
#include <time.h>
#include <conio.h>

#define MAX_CHAR 30
#define ps 0.5
#define VERSION "v1.0"

typedef struct {
    int matricule;
    char marque[MAX_CHAR];
    int nombrePlaces;
    bool disponible;
} Vehicule;

typedef struct {
    Vehicule *listeVehicules;
    int nombreVehicules;
} ParcAuto;

typedef struct {
    char client[MAX_CHAR];
    int matriculeVehicule;
    char dateDebut[MAX_CHAR];
    char dateFin[MAX_CHAR];
} Location;

typedef struct {
    Location *listeLocations;
    int nombreLocations;
} HistoriqueLocations;

void E_Cars() {
    printf("_________________________________________________________________________________________________________________________________________\n");
    printf("*****************************************************************************************************************************************\n");
    printf("\n\tEEEEEEEEEEEEEEEEEEEEEE                              CCCCCCCCCCCCC\n");
    printf("\tE::::::::::::::::::::E                           CCC::::::::::::C   \n");
    printf("\tE::::::::::::::::::::E                         CC:::::::::::::::C\n");
    printf("\tEE::::::EEEEEEEEE::::E                        C:::::CCCCCCCC::::C   \n");
    printf("\t  E:::::E       EEEEEE                       C:::::C       CCCCCC  aaaaaaaaaaaaa  rrrrr   rrrrrrrrr       ssssssssss  \n");
    printf("\t  E:::::E                                   C:::::C                a::::::::::::a r::::rrr:::::::::r    ss::::::::::s  \n");
    printf("\t  E::::::EEEEEEEEEE                         C:::::C                aaaaaaaaa:::::ar:::::::::::::::::r ss:::::::::::::s \n");
    printf("\t  E:::::::::::::::E    ---------------      C:::::C                         a::::arr::::::rrrrr::::::rs::::::ssss:::::s\n");
    printf("\t  E:::::::::::::::E    -:::::::::::::-      C:::::C                  aaaaaaa:::::a r:::::r     r:::::r s:::::s  ssssss \n");
    printf("\t  E::::::EEEEEEEEEE    ---------------      C:::::C                aa::::::::::::a r:::::r     rrrrrrr   s::::::s      \n");
    printf("\t  E:::::E                                   C:::::C               a::::aaaa::::::a r:::::r                  s::::::s  \n");
    printf("\t  E:::::E       EEEEEE                       C:::::C       CCCCCCa::::a    a:::::a r:::::r            ssssss   s:::::s \n");
    printf("\tEE::::::EEEEEEEE:::::E                        C:::::CCCCCCCC::::Ca::::a    a:::::a r:::::r            s:::::ssss::::::s\n");
    printf("\tE::::::::::::::::::::E                         CC:::::::::::::::Ca:::::aaaa::::::a r:::::r            s::::::::::::::s \n");
    printf("\tE::::::::::::::::::::E                           CCC::::::::::::C a::::::::::aa:::ar:::::r             s:::::::::::ss  \n");
    printf("\tEEEEEEEEEEEEEEEEEEEEEE                              CCCCCCCCCCCCC  aaaaaaaaaa  aaaarrrrrrr              sssssssssss\n");
    printf("_________________________________________________________________________________________________________________________________________\n");
    printf("*****************************************************************************************************************************************\n");
}

void menu() {
    printf("\n\n_________________________________________________________________________________________________________________________________________\n");
    printf("*****************************************************************************************************************************************\n");
    printf("1	. Ajouter un vehicule .\n");
    printf("2	. Afficher le parc automobile .\n");
    printf("3	. Louer un vehicule .\n");
    printf("4	. Retourner un vehicule suite a une reclamation .\n");
    printf("5 	. Afficher l'historique des locations .\n");
    printf("6 	. Modifier une vehicule .\n");
    printf("7 	. Supprimer une vehicule .\n");
    printf("8   	. Credits .\n");
    printf("9	. Quitter .\n");
    printf("_________________________________________________________________________________________________________________________________________\n");
    printf("*****************************************************************************************************************************************\n");
}

void delay(float number_of_seconds) {
    float milli_seconds = 1000 * number_of_seconds;
    clock_t start_time = clock();
    while (clock() < start_time + milli_seconds);
}

void load() {
    printf("Loading");
    delay(ps);
    printf(".");
    delay(ps);
    printf(".");
    delay(ps);
    printf(".\n");
    delay(ps);
    system("cls");
}

void loadCredits() {
    delay(0.25);
    printf(".");
    delay(0.25);
    printf(".");
    delay(0.25);
    printf(".");
    delay(0.25);
}

void CreditsMenu() {
    system("cls");
    E_Cars();
    printf("\n\n\nVersion: %s\n", VERSION);
    puts("GitHub link: {https://github.com/yassine-grati/projet-C-E-Cars}\n");
    int i;
    char string[] = "This is an educational project written by: \nYassine Grati\n";
    for (i = 0; i < strlen(string); i++) {
        putchar(string[i]);
        delay(0.055);
    }
    getch();
}

void saisirVehicule(Vehicule *vehicule) {
    printf("Matricule : ");
    scanf("%d", &vehicule->matricule);
    printf("Marque : ");
    scanf("%s", vehicule->marque);
    printf("Nombre de places : ");
    scanf("%d", &vehicule->nombrePlaces);
    vehicule->disponible = true;
}

void afficherVehicule(Vehicule vehicule) {
    printf("Matricule : %d\n", vehicule.matricule);
    printf("Marque : %s\n", vehicule.marque);
    printf("Nombre de places : %d\n", vehicule.nombrePlaces);
    printf("Disponible : %s\n", vehicule.disponible ? "Oui" : "Non");
}

void initParcAuto(ParcAuto *parcAuto, int taille) {
    parcAuto->listeVehicules = (Vehicule *)malloc(taille * sizeof(Vehicule));
    parcAuto->nombreVehicules = 0;
}

void ajouterVehicule(ParcAuto *parcAuto, Vehicule vehicule) {
    parcAuto->listeVehicules[parcAuto->nombreVehicules] = vehicule;
    (parcAuto->nombreVehicules)++;
}

void afficherParcAuto(ParcAuto parcAuto) {
    printf("Parc Auto :\n");
    for (int i = 0; i < parcAuto.nombreVehicules; i++) {
        afficherVehicule(parcAuto.listeVehicules[i]);
        printf("------------------------------\n");
    }
    getch();
}

int rechercheVehiculeParMatricule(ParcAuto parcAuto, int matricule) {
    for (int i = 0; i < parcAuto.nombreVehicules; i++) {
        if (parcAuto.listeVehicules[i].matricule == matricule) {
            return i;
        }
    }
    return -1;
}


int retourVehiculeReclamation(ParcAuto *parcAuto, HistoriqueLocations *historique) {
    int matricule;
    printf("Matricule du vehicule a retourner suite a une reclamation : ");
    scanf("%d", &matricule);

    int indexVehicule = rechercheVehiculeParMatricule(*parcAuto, matricule);

    if (indexVehicule != -1 && !parcAuto->listeVehicules[indexVehicule].disponible) {
        parcAuto->listeVehicules[indexVehicule].disponible = true;

        for (int i = 0; i < historique->nombreLocations; i++) {
            if (historique->listeLocations[i].matriculeVehicule == matricule) {
                for (int j = i; j < historique->nombreLocations - 1; j++) {
                    historique->listeLocations[j] = historique->listeLocations[j + 1];
                }
                (historique->nombreLocations)--;
                printf("Vehicule retourne suite a une reclamation avec succes!\n");
                return 0;
            }
        }

        printf("Location introuvable dans l'historique.\n");
        return -1;
    } else {
        printf("Vehicule non trouve ou deja disponible.\n");
        return -1;
    }
}


void modifierVehicule(ParcAuto *parcAuto) {
    int matricule,a=0;
    printf("Matricule du vehicule a modifier : ");
    scanf("%d", &matricule);

    int indexVehicule = rechercheVehiculeParMatricule(*parcAuto, matricule);

    if (indexVehicule != -1) {
        Vehicule *vehicule = &parcAuto->listeVehicules[indexVehicule];

        printf("Nouvelle marque : ");
        scanf("%s", vehicule->marque);
        printf("Nouveau nombre de places : ");
        scanf("%d", &vehicule->nombrePlaces);
        while (a!=1 && a!=2){
            printf("est ce que le vehicule est disponible : \n 1:oui   2:non ");
            scanf("%d",&a);
        }
        if (a==1){
            vehicule->disponible=true;
        }
        else{
            vehicule->disponible=false;
        }
        printf("Modification effectuee avec succes!\n");
    } else {
        printf("Vehicule non trouve.\n");
    }
}

void supprimerVehicule(ParcAuto *parcAuto) {
    int matricule;
    printf("Matricule du vehicule a supprimer : ");
    scanf("%d", &matricule);

    int indexVehicule = rechercheVehiculeParMatricule(*parcAuto, matricule);

    if (indexVehicule != -1) {
        for (int i = indexVehicule; i < parcAuto->nombreVehicules - 1; i++) {
            parcAuto->listeVehicules[i] = parcAuto->listeVehicules[i + 1];
        }
        (parcAuto->nombreVehicules)--;
        printf("Vehicule supprime avec succes!\n");
    } else {
        printf("Vehicule non trouve.\n");
    }
}




void louerVehicule(ParcAuto *parcAuto, HistoriqueLocations *historique) {
    int matricule;
    printf("Matricule du vehicule a louer : ");
    scanf("%d", &matricule);

    int indexVehicule = rechercheVehiculeParMatricule(*parcAuto, matricule);

    if (indexVehicule != -1 && parcAuto->listeVehicules[indexVehicule].disponible) {
        parcAuto->listeVehicules[indexVehicule].disponible = false;

        Location location;
        strcpy(location.client, "Client Test");
        location.matriculeVehicule = matricule;
        strcpy(location.dateDebut, "01/01/2023");
        strcpy(location.dateFin, "07/01/2023");

        historique->listeLocations[historique->nombreLocations] = location;
        (historique->nombreLocations)++;
        printf("Location effectuee avec succes!\n");
    } else {
        printf("Vehicule non trouve ou deja loue.\n");
    }
}

void afficherHistoriqueLocations(HistoriqueLocations historique) {
    printf("Historique des locations :\n");
    for (int i = 0; i < historique.nombreLocations; i++) {
        printf("Client : %s\n", historique.listeLocations[i].client);
        printf("Matricule du vehicule : %d\n", historique.listeLocations[i].matriculeVehicule);
        printf("Date de d�but : %s\n", historique.listeLocations[i].dateDebut);
        printf("Date de fin : %s\n", historique.listeLocations[i].dateFin);
        printf("------------------------------\n");
    }
}

int main() {
    ParcAuto parc;
    HistoriqueLocations historique;
    initParcAuto(&parc, MAX_CHAR);
    historique.listeLocations = (Location *)malloc(MAX_CHAR * sizeof(Location));
    historique.nombreLocations = 0;

    int choix;
    do {
        system("cls");
        E_Cars();
        menu();
        printf("\nChoix : ");
        scanf("%d", &choix);
        switch (choix) {
            case 1:
                {
                    Vehicule nouveauVehicule;
                    saisirVehicule(&nouveauVehicule);
                    ajouterVehicule(&parc, nouveauVehicule);
                }
                getch();
                break;
            case 2:
                afficherParcAuto(parc);
                getch();
                break;
            case 3:
                louerVehicule(&parc, &historique);
                getch();
                break;
            case 4:
                retourVehiculeReclamation(&parc, &historique);
                printf("Nous vous remercions de nous avoir contactes concernant votre recente experience de location de voiture avec E-CARS Nous prenons tres au serieux toutes les preoccupations de nos clients et nous nous excusons sincerement pour les desagrement que vous avez rencontres Nous tenons a vous assurer que nous prenons des mesures immediates pour resoudre ce probleme. Notre equipe technique examinera la voiture en question et effectuera les reparations necessaires pour garantir son bon etat de fonctionnement \n");
                getch();
                break;
            case 5:
                afficherHistoriqueLocations(historique);
                getch();
                break;
            case 6:
			    modifierVehicule(&parc);
			    getch();
			    break;
            case 7:
                supprimerVehicule(&parc);
                getch();
			    break;
			case 8:
				load();
                CreditsMenu();
                getch();
                break;

            case 9:
                exit(0);

                break;
            default:
                printf("Choix invalide.\n");
                delay(3);
                getch();
                break;
        }
    } while (choix != 10);

    free(parc.listeVehicules);
    free(historique.listeLocations);

    return 0;
}
